=== Multisite MediaSync ===
Contributors: seangruenboeck
Donate link: 
Tags: multisite, media, upload, uploads, admin, image, photo, sync
Requires at least: 2.8
Tested up to: 4.6
Stable tag: 1.0

Multisite MediaSync syncs the Media Posts in WP Posts tables for all blogs within a multisite installation.
And it makes sure that all uploads are only saved and read from the main uploads folder.

== Description ==


== Installation ==

Upload the plugin to your blog, activate it, done.
To do the initial sync, simply go to (Tools -> Multisite Mediasync).
Subsequent uploads, deletions and meta changes will be synced automatically.

== Changelog ==

= 1.0 =

* Initial release / Tested with WP 4.6

== Screenshots ==
